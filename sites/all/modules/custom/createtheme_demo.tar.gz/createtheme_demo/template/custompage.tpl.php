<h1><?php print $title; ?></h1>
<h1><?php print $company; ?></h1>
<h1><?php print $user_password; ?></h1>
<p><?php print $desc; ?></p>
